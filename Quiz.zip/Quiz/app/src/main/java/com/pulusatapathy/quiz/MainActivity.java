package com.pulusatapathy.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {
    int t = 0;
    private EditText editText1, editText2;
    private TextView textView, textView2, score_is;
    private RadioButton radioButton1_1, radioButton1_2, radioButton1_3, radioButton1_4;
    private RadioButton radioButton_2_1, radioButton_2_2;
    private CheckBox checkBox1_1, checkBox1_2, checkBox1_3, checkBox1_4, checkBox1_5;
    private RadioButton radioButton5_1, radioButton5_2, radioButton5_3, radioButton5_4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        radioButton1_1 = findViewById(R.id.Shahjahan);
        radioButton1_2 = findViewById(R.id.Aurangzeb);
        radioButton1_3 = findViewById(R.id.Akbar);
        radioButton1_4 = findViewById(R.id.Jahangir);

        radioButton_2_1 = findViewById(R.id.RadioButton_Yes);
        radioButton_2_2 = findViewById(R.id.RadioButton_No);

        textView2 = findViewById(R.id.EditText_setName);
        score_is = findViewById(R.id.score_is);
        textView = findViewById(R.id.numberScore);
        editText1 = findViewById(R.id.EditText_getName);
        editText2 = findViewById(R.id.Edittext_astronutName);

        checkBox1_1 = findViewById(R.id.Arunachal_Pradesh);
        checkBox1_2 = findViewById(R.id.Madhya_Pradesh);
        checkBox1_3 = findViewById(R.id.West_Bengal);
        checkBox1_4 = findViewById(R.id.Haryana);
        checkBox1_5 = findViewById(R.id.Odisha);

        radioButton5_1 = findViewById(R.id.Government_of_Maharashtra);
        radioButton5_2 = findViewById(R.id.Archaeological_Survey_of_India);
        radioButton5_3 = findViewById(R.id.Ministry_of_Culture);
        radioButton5_4 = findViewById(R.id.Ministry_of_Tourism);


    }

    public void submit(View view) {
        String getName = editText1.getText().toString();
        textView2.setText(getName);

        boolean booleanAkbar = radioButton1_3.isChecked();

        boolean No = radioButton_2_2.isChecked();

        boolean AP = checkBox1_1.isChecked();
        boolean MP = checkBox1_2.isChecked();
        boolean WB = checkBox1_3.isChecked();
        boolean HR = checkBox1_4.isChecked();
        boolean OD = checkBox1_5.isChecked();

        String astronautName = editText2.getText().toString();
        boolean booleanArchaeological = radioButton5_2.isChecked();


        int ansewrOfQuestion1 = ques1(booleanAkbar);
        int ansewrOfQuestion2 = ques2(No);
        int ansewrOfQuestion3 = ques3(AP, MP, WB, HR, OD);
        int ansewrOfQuestion4 = ques4(astronautName);
        int ansewrOfQuestion5 = ques5(booleanArchaeological);


        int score = counter(ansewrOfQuestion1, ansewrOfQuestion2, ansewrOfQuestion3, ansewrOfQuestion4, ansewrOfQuestion5);

        score_is.setText(R.string.your_score_is);
        textView.setText(String.format(score + "/5"));
        String a = getString(R.string.your_score_is) + " " + String.valueOf(score) + "\n" + getString(R.string.tryagn) + "\n" + getString(R.string.thnx);
        Toast.makeText(getApplicationContext(), a, LENGTH_SHORT).show();


    }

    private int counter(int ansewrOfQuestion1, int ansewrOfQuestion2, int ansewrOfQuestion3, int ansewrOfQuestion4, int ansewrOfQuestion5) {
        int tempScore = 0;
        int[] temp = {ansewrOfQuestion1, ansewrOfQuestion2, ansewrOfQuestion3, ansewrOfQuestion4, ansewrOfQuestion5};
        for (int i : temp) {
            tempScore = tempScore + i;
        }
        return tempScore;


    }

    private int ques5(boolean booleanArchaeological) {
        if (booleanArchaeological) {
            return 1;

        } else {
            return 0;
        }
    }

    private int ques4(String astronautName) {
        String astronautAnswer = "Rakesh Sharma";
        if (astronautName.equalsIgnoreCase(astronautAnswer)) {
            return 1;

        } else {
            return 0;
        }
    }

    private int ques3(boolean ap, boolean mp, boolean wb, boolean hr, boolean od) {
        if (ap && mp && od && !wb && !hr) {
            return 1;

        } else {
            return 0;
        }
    }

    private int ques2(boolean no) {

        if (no) {
            return 1;

        } else {
            return 0;
        }

    }

    public int ques1(boolean Akbr) {
        if (Akbr) {
            return 1;

        } else {
            return 0;
        }
    }
}
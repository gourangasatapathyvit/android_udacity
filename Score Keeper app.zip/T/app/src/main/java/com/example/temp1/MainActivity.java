package com.example.temp1;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    private TextView showTextView1, ShowTextView2;
    private int num = 0;
    private int num2 = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showTextView1 = findViewById(R.id.lnr1ScoreimageView);
        ShowTextView2 = findViewById(R.id.lnr2ScoreimageView);


    }

    public void p(int i, int j) {
        int intnum1 = i;
        int intnum2 = j;
        if (intnum1 > intnum2) {
            showTextView1.setTextColor(getResources().getColor(R.color.plus));
            ShowTextView2.setTextColor(getResources().getColor(R.color.minus));
        }
        if (intnum1 < intnum2) {
            ShowTextView2.setTextColor(getResources().getColor(R.color.plus));
            showTextView1.setTextColor(getResources().getColor(R.color.minus));
        }


    }

    public void colorCInitial() {
        ShowTextView2.setTextColor(getResources().getColor(R.color.initial));
        showTextView1.setTextColor(getResources().getColor(R.color.initial));


    }

    public void button1(View view) {
        num += 6;
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        p(num, num2);

    }

    public void button2(View view) {
        num += 3;
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        p(num, num2);
    }

    public void button3(View view) {
        num += 2;
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        p(num, num2);
    }

    public void button4(View view) {
        num += 1;
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        p(num, num2);
    }

    public void button5(View view) {
        num += 2;
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        p(num, num2);
    }

    public void button11(View view) {
        num2 += 6;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        p(num, num2);
    }

    public void button22(View view) {
        num2 += 3;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        p(num, num2);
    }

    public void button33(View view) {
        num2 += 2;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        p(num, num2);
    }

    public void button44(View view) {
        num2 += 1;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        p(num, num2);
    }

    public void button55(View view) {
        num2 += 2;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        p(num, num2);
    }

    public void endButton(View view) {
        num2 = 0;
        num = 0;
        ShowTextView2.setText(String.valueOf(NumberFormat.getInstance().format(num2)));
        showTextView1.setText(String.valueOf(NumberFormat.getInstance().format(num)));
        colorCInitial();
        Toast.makeText(getApplicationContext(), "Reset tapped", Toast.LENGTH_SHORT).show();
    }
}
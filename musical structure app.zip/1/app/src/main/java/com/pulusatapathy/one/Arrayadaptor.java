package com.pulusatapathy.one;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Arrayadaptor extends ArrayAdapter<Instrument_tone> {


    public Arrayadaptor(Context context, ArrayList<Instrument_tone> arrayList) {
        super(context, 0, arrayList);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.list_view, parent, false);
        }

        final Instrument_tone wordObj = getItem(position);
        ImageView imageView = view.findViewById(R.id.list_imageView);
        TextView textView = view.findViewById(R.id.list_textView);
        textView.setText(wordObj.getName());

        imageView.setImageResource(wordObj.getImage_obj());


        return view;


    }
}

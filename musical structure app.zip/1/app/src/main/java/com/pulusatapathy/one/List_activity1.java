package com.pulusatapathy.one;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class List_activity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_list_activity);
        ArrayList<Instrument_tone> arrayList = new ArrayList();
        arrayList.add(new Instrument_tone(R.drawable.cat_128px, "cat"));
        arrayList.add(new Instrument_tone(R.drawable.dog_48px, "dog"));
        arrayList.add(new Instrument_tone(R.drawable.cow_40px, "cow"));
        arrayList.add(new Instrument_tone(R.drawable.year_of_horse_48px, "horse"));
        arrayList.add(new Instrument_tone(R.drawable.pig_40px, "pig"));


        Arrayadaptor arrayadaptor = new Arrayadaptor(this, arrayList);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(arrayadaptor);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(List_activity1.this, "playing", Toast.LENGTH_SHORT).show();
            }
        });


    }
}

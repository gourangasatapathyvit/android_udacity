package com.pulusatapathy.one;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class List_activity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_list_activity);
        ArrayList<Instrument_tone> arrayList = new ArrayList();
        arrayList.add(new Instrument_tone(R.drawable.pixel, "pixel"));
        arrayList.add(new Instrument_tone(R.drawable.us_music_48px, "pop"));
        arrayList.add(new Instrument_tone(R.drawable.rock_music_64px, "rock music"));
        arrayList.add(new Instrument_tone(R.drawable.pixel, "pixel 2.0"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "music mania"));
        arrayList.add(new Instrument_tone(R.drawable.party_64px, "party mode"));
        arrayList.add(new Instrument_tone(R.drawable.herald_trumpet_48px, "jazz"));
        arrayList.add(new Instrument_tone(R.drawable.music_folder_48px, "offline music"));
        arrayList.add(new Instrument_tone(R.drawable.google_play_music_48px, "google music"));
        arrayList.add(new Instrument_tone(R.drawable.soundcloud_48px, "sound cloud"));
        arrayList.add(new Instrument_tone(R.drawable.exercise_40px, "sound cloud"));


        Arrayadaptor arrayadaptor = new Arrayadaptor(this, arrayList);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(arrayadaptor);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(List_activity5.this, "playing", Toast.LENGTH_SHORT).show();
            }
        });

    }
}

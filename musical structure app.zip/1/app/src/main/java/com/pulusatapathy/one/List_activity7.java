package com.pulusatapathy.one;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class List_activity7 extends AppCompatActivity {
    private final int NR_OF_SIMULTANEOUS_SOUNDS = 7;
    private final float leftVolume = 1.0f;
    private final float rightVolume = 1.0f;
    private final int priority = 0;
    private final int loop = 0;
    private final float rate = 1.0f;

    // Member Variables
    SoundPool mSoundPool;
    int mCSoundId;
    int mESoundId;
    int mDSoundId;
    int mFSoundId;
    int mGSoundId;
    int mASoundId;
    int mBSoundId;
    int pauseSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.xylophone);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            mSoundPool = new SoundPool.Builder()
                    .setMaxStreams(1)
                    .setAudioAttributes(audioAttributes)
                    .build();


        } else {

            mSoundPool = new SoundPool(7, AudioManager.STREAM_MUSIC, 0);
        }


        // Get the resource IDs to identify the sounds and store them in variables
        mCSoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note2_d, 1);
        mDSoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note2_d, 1);
        mESoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note3_e, 1);
        mFSoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note4_f, 1);
        mGSoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note5_g, 1);
        mASoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note6_a, 1);
        mBSoundId = mSoundPool.load(getApplicationContext(), R.raw.ee_note7_b, 1);

    }

    // Individual methods linked to onClick properties in the XML layout file
    public void playC(View v) {
        pauseSound = mSoundPool.play(mCSoundId, leftVolume, rightVolume, priority, loop, rate);
    }

    public void playA(View v) {
        mSoundPool.play(mASoundId, leftVolume, rightVolume, priority, loop, rate);

    }

    public void playB(View v) {
        mSoundPool.play(mBSoundId, leftVolume, rightVolume, priority, loop, rate);

    }

    public void playD(View v) {
        mSoundPool.play(mDSoundId, leftVolume, rightVolume, priority, loop, rate);

    }

    public void playE(View v) {
        mSoundPool.play(mESoundId, leftVolume, rightVolume, priority, loop, rate);

    }

    public void playF(View v) {
        mSoundPool.play(mFSoundId, leftVolume, rightVolume, priority, loop, rate);

    }

    public void playG(View v) {
        mSoundPool.play(mGSoundId, leftVolume, rightVolume, priority, loop, rate);


    }

//    public void myButton(View view) {
//        mSoundPool.pause(pauseSound);
//    }
//
//    public void myButton2(View view) {
////        mSoundPool.resume(pauseSound);
//        mSoundPool.setRate(pauseSound, 0.7f);
////            mSoundPool.setVolume(pauseSound,1.0f,1.0f);
//
//
//    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSoundPool.release();
        mSoundPool = null;
    }
}
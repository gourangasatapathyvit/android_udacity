package com.pulusatapathy.one;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class List_activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_list_activity);
        ArrayList<Instrument_tone> arrayList = new ArrayList();
        arrayList.add(new Instrument_tone(R.drawable.dinosaur_48px, "jaguar"));
        arrayList.add(new Instrument_tone(R.drawable.frog_face_50px, "frog"));
        arrayList.add(new Instrument_tone(R.drawable.gorilla_40px, "gorilla"));
        arrayList.add(new Instrument_tone(R.drawable.lion_48px, "lion"));
        arrayList.add(new Instrument_tone(R.drawable.tiger_48px, "tiger"));
        arrayList.add(new Instrument_tone(R.drawable.snake_50px, "snake"));
        arrayList.add(new Instrument_tone(R.drawable.tiger, "jaguar"));

        Arrayadaptor arrayadaptor = new Arrayadaptor(this, arrayList);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(arrayadaptor);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(List_activity2.this, "playing", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

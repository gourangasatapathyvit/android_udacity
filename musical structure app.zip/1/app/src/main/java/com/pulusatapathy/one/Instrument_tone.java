package com.pulusatapathy.one;

public class Instrument_tone {


    private int image_obj;
    private String name;


    public Instrument_tone(int image_obj, String name) {
        this.image_obj = image_obj;
        this.name = name;

    }

    public int getImage_obj() {
        return image_obj;
    }

    public void setImage_obj(int image_obj) {
        this.image_obj = image_obj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

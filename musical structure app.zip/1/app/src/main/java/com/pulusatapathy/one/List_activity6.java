package com.pulusatapathy.one;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class List_activity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_list_activity);
        ArrayList<Instrument_tone> arrayList = new ArrayList();
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel1"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel2"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel3"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel4"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel5"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel6"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel7"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel8"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel9"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel10"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel11"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel12"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel13"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel14"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel15"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel16"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel17"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel18"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel19"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel20"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel21"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel22"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel23"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel24"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel25"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel26"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel27"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel28"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel29"));
        arrayList.add(new Instrument_tone(R.drawable.music_50px, "pixel30"));


        Arrayadaptor arrayadaptor = new Arrayadaptor(this, arrayList);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(arrayadaptor);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(List_activity6.this, "playing", Toast.LENGTH_SHORT).show();
            }
        });

    }
}

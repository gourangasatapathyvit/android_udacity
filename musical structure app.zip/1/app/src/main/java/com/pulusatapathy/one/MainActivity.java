package com.pulusatapathy.one;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView AnimalPage = findViewById(R.id.clmn1);
        AnimalPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, animalPage.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "\uD83D\uDC02", Toast.LENGTH_SHORT).show();

            }
        });
        TextView birdPage = findViewById(R.id.clmn2);
        birdPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, birdPage.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "\uD83E\uDD83", Toast.LENGTH_SHORT).show();

            }
        });
        TextView bellPage = findViewById(R.id.clmn3);
        bellPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, bellactivity.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "\uD83D\uDD14\uD83D\uDD14", Toast.LENGTH_SHORT).show();


            }
        });
        TextView xyloPage = findViewById(R.id.clmn4);
        xyloPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, xylophone.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "\uD83C\uDFBC\uD83C\uDFBC", Toast.LENGTH_SHORT).show();


            }
        });

    }
}
